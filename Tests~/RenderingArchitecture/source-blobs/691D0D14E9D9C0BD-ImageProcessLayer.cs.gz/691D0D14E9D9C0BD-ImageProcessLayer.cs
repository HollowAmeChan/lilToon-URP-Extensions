using System;
using UnityEngine;

namespace lilToon.URP.Extensions.PostProcessing
{
    [Serializable]
    public sealed class ImageProcessLayer
    {
        [Tooltip("显示在 Volume 图层列表里的名称。")]
        public string name = "Post Process Layer";

        [Tooltip("不从列表移除，但跳过这个图层。")]
        public bool enabled = true;

        [Tooltip("这个图层对应的 ImageProcess 效果。Custom Material 会直接使用材质或 Shader 覆盖。")]
        public ImageProcessEffect effect = ImageProcessEffect.CustomMaterial;

        [Tooltip("可选材质覆盖。移植新 Shader 时最安全。")]
        public Material materialOverride;

        [Tooltip("可选 Shader 覆盖。运行时会为它创建并缓存材质。")]
        public Shader shaderOverride;

        [Tooltip("这个图层使用的 Shader Pass 索引。")]
        [Min(0)]
        public int passIndex;

        [Tooltip("图层强度。移植的 Shader 应该读取 _Intensity。")]
        [Range(0.0f, 1.0f)]
        public float intensity = 1.0f;

        [Tooltip("混合模式。会以 _LayerBlendMode 暴露给 Shader。")]
        public ImageProcessBlendMode blendMode = ImageProcessBlendMode.Normal;

        [Tooltip("颜色参数。会以 _LayerColor 暴露给 Shader。")]
        public Color color = Color.white;

        [Tooltip("可选纹理。会以 _LayerTexture 暴露给 Shader。")]
        public Texture texture;

        [Tooltip("渐变映射（GradientMap）的色标。运行时会烘焙成 1x256 的 ramp 贴图并以 _LayerRampTex 交给 Shader；" +
                 "支持 Unity 渐变的 8 个颜色键 + 8 个透明度键与 Blend/Fixed 模式。")]
        public Gradient ramp = ImageProcessGradientRampCache.CreateDefaultGradient();

        [Tooltip("Logo overlay input texture 0.")]
        public Texture logoTexture0;

        [Tooltip("Logo overlay input texture 1.")]
        public Texture logoTexture1;

        [Tooltip("Logo overlay input texture 2.")]
        public Texture logoTexture2;

        [Tooltip("Logo overlay input texture 3.")]
        public Texture logoTexture3;

        [Tooltip("Logo overlay input texture 4.")]
        public Texture logoTexture4;

        [Tooltip("Logo overlay input texture 5.")]
        public Texture logoTexture5;

        [Tooltip("Logo overlay input texture 6.")]
        public Texture logoTexture6;

        [Tooltip("Logo overlay input texture 7.")]
        public Texture logoTexture7;

        [Tooltip("通用参数向量 0。会以 _LayerParams0 暴露给 Shader。")]
        public Vector4 parameters0;

        [Tooltip("通用参数向量 1。会以 _LayerParams1 暴露给 Shader。")]
        public Vector4 parameters1;

        [Tooltip("通用参数向量 2。会以 _LayerParams2 暴露给 Shader。")]
        public Vector4 parameters2;

        [Tooltip("通用参数向量 3。会以 _LayerParams3 暴露给 Shader。")]
        public Vector4 parameters3;

        [Tooltip("通用参数向量 4。会以 _LayerParams4 暴露给 Shader。")]
        public Vector4 parameters4;

        [Tooltip("通用参数向量 5。会以 _LayerParams5 暴露给 Shader。")]
        public Vector4 parameters5;

        [Tooltip("通用参数向量 6。会以 _LayerParams6 暴露给 Shader。")]
        public Vector4 parameters6;

        [Tooltip("通用参数向量 7。会以 _LayerParams7 暴露给 Shader。")]
        public Vector4 parameters7;

        [Tooltip("通用参数向量 8。会以 _LayerParams8 暴露给 Shader。")]
        public Vector4 parameters8;

        [Tooltip("通用参数向量 9。会以 _LayerParams9 暴露给 Shader。")]
        public Vector4 parameters9;

        [Tooltip("通用参数向量 10。会以 _LayerParams10 暴露给 Shader。")]
        public Vector4 parameters10;

        [Tooltip("通用参数向量 11。会以 _LayerParams11 暴露给 Shader。")]
        public Vector4 parameters11;

        [Tooltip("通用参数向量 12。会以 _LayerParams12 暴露给 Shader。")]
        public Vector4 parameters12;

        public bool IsActive => enabled && intensity > 0.0f;

        /// <summary>Width of the baked GradientMap ramp texture (1 x <see cref="RampResolution"/>).</summary>
        public const int RampResolution = 256;

        /// <summary>
        /// Bakes <paramref name="source"/> into display-space RGBA ramp samples: the same ramp the
        /// GradientMap effect samples on the GPU, exposed so tools (and the inspector preview) can
        /// evaluate it without duplicating the interpolation maths.
        /// </summary>
        /// <param name="destination">Buffer of at least <c>RampResolution * 4</c> floats.</param>
        /// <returns>False when there is nothing to bake (no gradient or a too-small buffer).</returns>
        public static bool BakeRamp(Gradient source, int space, float[] destination, out bool fixedMode)
        {
            fixedMode = source != null && source.mode == GradientMode.Fixed;
            if (source == null || destination == null || destination.Length < RampResolution * 4)
            {
                return false;
            }

            GradientColorKey[] sourceColors = source.colorKeys ?? Array.Empty<GradientColorKey>();
            int colorCount = Math.Min(sourceColors.Length, ImageProcessGradientRampBaker.MaxKeys);
            var colorKeys = new ImageProcessGradientRampBaker.ColorKey[ImageProcessGradientRampBaker.MaxKeys];
            for (int i = 0; i < colorCount; i++)
            {
                GradientColorKey key = sourceColors[i];
                colorKeys[i] = new ImageProcessGradientRampBaker.ColorKey(
                    key.time, key.color.r, key.color.g, key.color.b);
            }

            GradientAlphaKey[] sourceAlphas = source.alphaKeys ?? Array.Empty<GradientAlphaKey>();
            int alphaCount = Math.Min(sourceAlphas.Length, ImageProcessGradientRampBaker.MaxKeys);
            var alphaKeys = new ImageProcessGradientRampBaker.AlphaKey[ImageProcessGradientRampBaker.MaxKeys];
            for (int i = 0; i < alphaCount; i++)
            {
                GradientAlphaKey key = sourceAlphas[i];
                alphaKeys[i] = new ImageProcessGradientRampBaker.AlphaKey(key.time, key.alpha);
            }

            ImageProcessGradientRampBaker.Bake(
                colorKeys,
                colorCount,
                alphaKeys,
                alphaCount,
                fixedMode,
                Mathf.Clamp(space, 0, ImageProcessGradientRampBaker.SpaceCount - 1),
                RampResolution,
                destination);
            return true;
        }

        /// <summary>Bakes this layer's ramp using its own interpolation space.</summary>
        public bool BakeRamp(float[] destination, out bool fixedMode)
        {
            return BakeRamp(
                ramp,
                Mathf.Clamp(Mathf.RoundToInt(parameters6.x), 0, ImageProcessGradientRampBaker.SpaceCount - 1),
                destination,
                out fixedMode);
        }
    }
}
