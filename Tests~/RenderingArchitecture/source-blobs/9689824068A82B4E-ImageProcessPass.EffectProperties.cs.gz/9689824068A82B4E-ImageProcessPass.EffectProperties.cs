using UnityEngine;
#pragma warning disable CS0618, CS0672

namespace lilToon.URP.Extensions.PostProcessing
{
    internal sealed partial class ImageProcessPass
    {
        private static void ApplyLayerProperties(ImageProcessLayer layer, Material material)
        {
            LayerPropertyBlock properties = LayerPropertyBlock.FromLayer(layer);
            ApplyEffectPropertyDefaults(layer.effect, ref properties);

            material.SetFloat(ImageProcessShaderConstants.IntensityId, layer.intensity);
            material.SetFloat(ImageProcessShaderConstants.SharpnessId, properties.Sharpness);
            material.SetFloat(ImageProcessShaderConstants.ModeId, layer.parameters0.x);
            material.SetFloat(ImageProcessShaderConstants.AngleId, layer.parameters0.z * Mathf.Deg2Rad);
            material.SetFloat(ImageProcessShaderConstants.LayerBlendModeId, (float)layer.blendMode);

            material.SetColor(ImageProcessShaderConstants.LayerColorId, properties.Color);
            material.SetFloat(ImageProcessShaderConstants.LayerTextureEnabledId, layer.texture != null ? 1.0f : 0.0f);
            material.SetVector(ImageProcessShaderConstants.LayerParams0Id, properties.Params0);
            material.SetVector(ImageProcessShaderConstants.LayerParams1Id, properties.Params1);
            material.SetVector(ImageProcessShaderConstants.LayerParams2Id, properties.Params2);
            material.SetVector(ImageProcessShaderConstants.LayerParams3Id, properties.Params3);
            material.SetVector(ImageProcessShaderConstants.LayerParams4Id, properties.Params4);
            material.SetVector(ImageProcessShaderConstants.LayerParams5Id, properties.Params5);
            material.SetVector(ImageProcessShaderConstants.LayerParams6Id, properties.Params6);
            material.SetVector(ImageProcessShaderConstants.LayerParams7Id, properties.Params7);
            material.SetVector(ImageProcessShaderConstants.LayerParams8Id, properties.Params8);
            material.SetVector(ImageProcessShaderConstants.LayerParams9Id, properties.Params9);
            material.SetVector(ImageProcessShaderConstants.LayerParams10Id, properties.Params10);
            material.SetVector(ImageProcessShaderConstants.LayerParams11Id, properties.Params11);
            material.SetVector(ImageProcessShaderConstants.LayerParams12Id, properties.Params12);
            if (layer.texture != null)
            {
                material.SetTexture(ImageProcessShaderConstants.LayerTextureId, layer.texture);
            }

            material.SetVector(
                ImageProcessShaderConstants.LogoTextureEnabled0Id,
                new Vector4(
                    layer.logoTexture0 != null ? 1.0f : 0.0f,
                    layer.logoTexture1 != null ? 1.0f : 0.0f,
                    layer.logoTexture2 != null ? 1.0f : 0.0f,
                    layer.logoTexture3 != null ? 1.0f : 0.0f));
            material.SetVector(
                ImageProcessShaderConstants.LogoTextureEnabled1Id,
                new Vector4(
                    layer.logoTexture4 != null ? 1.0f : 0.0f,
                    layer.logoTexture5 != null ? 1.0f : 0.0f,
                    layer.logoTexture6 != null ? 1.0f : 0.0f,
                    layer.logoTexture7 != null ? 1.0f : 0.0f));
            SetLogoTexture(material, 0, layer.logoTexture0);
            SetLogoTexture(material, 1, layer.logoTexture1);
            SetLogoTexture(material, 2, layer.logoTexture2);
            SetLogoTexture(material, 3, layer.logoTexture3);
            SetLogoTexture(material, 4, layer.logoTexture4);
            SetLogoTexture(material, 5, layer.logoTexture5);
            SetLogoTexture(material, 6, layer.logoTexture6);
            SetLogoTexture(material, 7, layer.logoTexture7);
        }

        private static void ApplyLayerRamp(ImageProcessRuntimeLayer runtimeLayer, Material material)
        {
            ApplyLayerRamp(runtimeLayer.rampTexture, material);
        }

        private static void ApplyLayerRamp(Texture2D ramp, Material material)
        {
            material.SetFloat(ImageProcessShaderConstants.LayerRampTextureEnabledId, ramp != null ? 1.0f : 0.0f);
            if (ramp == null)
            {
                return;
            }

            material.SetTexture(ImageProcessShaderConstants.LayerRampTextureId, ramp);
            // The shader stretches its ramp coordinate by half a texel (see GradientMap.shader), so
            // it needs the texel size; passing it explicitly keeps the binding independent of
            // whether Unity fills in _LayerRampTex_TexelSize for a runtime-created texture.
            material.SetVector(
                ImageProcessShaderConstants.LayerRampTexelSizeId,
                new Vector4(1.0f / Mathf.Max(ramp.width, 1), 1.0f / Mathf.Max(ramp.height, 1), ramp.width, ramp.height));
        }

        private static void SetLogoTexture(Material material, int index, Texture texture)
        {
            if (texture == null)
            {
                return;
            }

            material.SetTexture(ImageProcessShaderConstants.LogoTextureIds[index], texture);
            material.SetVector(
                ImageProcessShaderConstants.LogoTextureTexelSizeIds[index],
                new Vector4(
                    1.0f / Mathf.Max(texture.width, 1),
                    1.0f / Mathf.Max(texture.height, 1),
                    texture.width,
                    texture.height));
        }

        private static void ApplyEffectPropertyDefaults(ImageProcessEffect effect, ref LayerPropertyBlock properties)
        {
            switch (effect)
            {
                case ImageProcessEffect.Fisheye:
                    ApplyFisheyePropertyDefaults(ref properties);
                    break;
                case ImageProcessEffect.SharpenBefore:
                case ImageProcessEffect.SharpenAfter:
                    ApplySharpenPropertyDefaults(ref properties);
                    break;
                case ImageProcessEffect.SkyGodRays:
                    ApplySkyGodRaysPropertyDefaults(ref properties);
                    break;
                case ImageProcessEffect.LogoOverlay:
                    ApplyLogoOverlayPropertyDefaults(ref properties);
                    break;
            }
        }

        private struct LayerPropertyBlock
        {
            public float Sharpness;
            public Color Color;
            public Vector4 Params0;
            public Vector4 Params1;
            public Vector4 Params2;
            public Vector4 Params3;
            public Vector4 Params4;
            public Vector4 Params5;
            public Vector4 Params6;
            public Vector4 Params7;
            public Vector4 Params8;
            public Vector4 Params9;
            public Vector4 Params10;
            public Vector4 Params11;
            public Vector4 Params12;

            public static LayerPropertyBlock FromLayer(ImageProcessLayer layer)
            {
                return new LayerPropertyBlock
                {
                    Sharpness = layer.parameters0.x,
                    Color = layer.color,
                    Params0 = layer.parameters0,
                    Params1 = layer.parameters1,
                    Params2 = layer.parameters2,
                    Params3 = layer.parameters3,
                    Params4 = layer.parameters4,
                    Params5 = layer.parameters5,
                    Params6 = layer.parameters6,
                    Params7 = layer.parameters7,
                    Params8 = layer.parameters8,
                    Params9 = layer.parameters9,
                    Params10 = layer.parameters10,
                    Params11 = layer.parameters11,
                    Params12 = layer.parameters12
                };
            }
        }

    }
}
