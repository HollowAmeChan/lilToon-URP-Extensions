// Ho-RTDI F0/RGB contrast/pair-bandwidth adaptation of NRD 4.17.3. Original SHA256: bc4c998e30852232ac98e4f2a7f924ef0072d900f44f4de1d725171f9e1508b8
/*
Copyright (c) 2022, NVIDIA CORPORATION. All rights reserved.

NVIDIA CORPORATION and its licensors retain all intellectual property
and proprietary rights in and to this software, related documentation
and any modifications thereto. Any use, reproduction, disclosure or
distribution of this software and related documentation without an express
license agreement from NVIDIA CORPORATION is strictly prohibited.
*/

#include "../../ThirdParty/NRD/NRD.hlsli"
#include "../../ThirdParty/NRD/ml.hlsli"

#include "../../ThirdParty/NRD/RELAX_Config.hlsli"
#include "../../ThirdParty/NRD/RELAX_Atrous.resources.hlsli"

#include "../../ThirdParty/NRD/Common.hlsli"

#include "../../ThirdParty/NRD/RELAX_Common.hlsli"
#include "HoRTDINrdMaterialGuide.hlsl"

[numthreads(GROUP_X, GROUP_Y, 1)]
NRD_EXPORT void NRD_CS_MAIN( NRD_CS_MAIN_ARGS )
{
    NRD_CTA_ORDER_DEFAULT;

    // Tile-based early out
    float isSky = gIn_Tiles[pixelPos >> 4];
    if (isSky != 0.0 || pixelPos.x >= gRectSize.x || pixelPos.y >= gRectSize.y)
        return;

    // Early out if linearZ is beyond denoising range
    float centerViewZ = UnpackViewZ(gIn_ViewZ[pixelPos]);
    if (centerViewZ > gDenoisingRange)
        return;

    float2 pixelUv = ( pixelPos + 0.5 ) * gRectSizeInv;

    float centerMaterialID;
    float4 centerNormalRoughness = NRD_FrontEnd_UnpackNormalAndRoughness(gIn_Normal_Roughness[pixelPos], centerMaterialID);
    float3 centerNormal = centerNormalRoughness.rgb;
    float centerRoughness = centerNormalRoughness.a;
    float historyLength = 255.0 * gIn_HistoryLength[pixelPos];

    // Diffuse normal weight is used for diffuse and can be used for specular depending on settings.
    // Weight strictness is higher as the Atrous step size increases.
    float diffuseLobeAngleFraction = gLobeAngleFraction / sqrt(gStepSize);
    #if( NRD_MODE == SH )
        diffuseLobeAngleFraction = 1.0 / sqrt(gStepSize);
    #endif
    diffuseLobeAngleFraction = lerp(0.99, diffuseLobeAngleFraction, saturate(historyLength / 5.0));

#if( NRD_SPEC )
    float4 centerSpecularIlluminationAndVariance = gIn_Spec_Variance[pixelPos];
    float centerSpecularLuminance = Color::Luminance(centerSpecularIlluminationAndVariance.rgb);
    float centerSpecularVar = centerSpecularIlluminationAndVariance.a;
    float specularPhiLIlluminationInv = 1.0 / max(1.0e-4, gSpecPhiLuminance * sqrt(centerSpecularVar));

    float2 roughnessWeightParams = GetRoughnessWeightParams(centerRoughness, gRoughnessFraction);
    float diffuseLobeAngleFractionForSimplifiedSpecularNormalWeight = diffuseLobeAngleFraction;
    float specularLobeAngleFraction = gLobeAngleFraction;

    float specularReprojectionConfidence = gIn_SpecReprojectionConfidence[pixelPos];
    float specularLuminanceWeightRelaxation = 1.0;
    if (gStepSize <= 4)
        specularLuminanceWeightRelaxation = lerp(1.0, specularReprojectionConfidence, gLuminanceEdgeStoppingRelaxation);

    if (gHasHistoryConfidence && NRD_SUPPORTS_HISTORY_CONFIDENCE)
    {
        // TODO: confidence is for previous frame, so "prev uv" should be used
        float specConfidenceDrivenRelaxation = saturate(gConfidenceDrivenRelaxationMultiplier * (1.0 - saturate(gIn_SpecConfidence.SampleLevel(gLinearClamp, pixelUv, 0))));

        // Relaxing normal weights for specular
        float r = saturate(specConfidenceDrivenRelaxation * gConfidenceDrivenNormalEdgeStoppingRelaxation);
        diffuseLobeAngleFractionForSimplifiedSpecularNormalWeight = lerp(diffuseLobeAngleFraction, 1.0, r);
        specularLobeAngleFraction = lerp(specularLobeAngleFraction, 1.0, r);

        // Relaxing luminance weight for specular
        r = saturate(specConfidenceDrivenRelaxation * gConfidenceDrivenLuminanceEdgeStoppingRelaxation);
        specularLuminanceWeightRelaxation *= 1.0 - r;
    }

    float specularNormalWeightParamSimplified = GetNormalWeightParam2(1.0, diffuseLobeAngleFractionForSimplifiedSpecularNormalWeight);
    float2 specularNormalWeightParams =
        GetNormalWeightParams_ATrous(
            centerRoughness,
            historyLength,
            specularReprojectionConfidence,
            gNormalEdgeStoppingRelaxation,
            specularLobeAngleFraction,
            gSpecLobeAngleSlack);

    float sumWSpecular = 0.44198 * 0.44198;
    float4 sumSpecularIlluminationAndVariance = centerSpecularIlluminationAndVariance * float4(sumWSpecular.xxx, sumWSpecular * sumWSpecular);
    #if( NRD_MODE == SH )
        float4 centerSpecularSH = gIn_SpecSh[pixelPos];
        float4 sumSpecularSH = centerSpecularSH * sumWSpecular;
        float roughnessModified = centerSpecularSH.w;
    #endif
#endif

#if( NRD_DIFF )
    float4 centerDiffuseIlluminationAndVariance = gIn_Diff_Variance[pixelPos];
    float centerDiffuseLuminance = Color::Luminance(centerDiffuseIlluminationAndVariance.rgb);
    float centerDiffuseVar = centerDiffuseIlluminationAndVariance.a;
    float diffusePhiLIlluminationInv = 1.0 / max(1.0e-4, gDiffPhiLuminance * sqrt(centerDiffuseVar));

    float diffuseLuminanceWeightRelaxation = 1.0;
    if (gHasHistoryConfidence && NRD_SUPPORTS_HISTORY_CONFIDENCE)
    {
        // TODO: confidence is for previous frame, so "prev uv" should be used
        float diffConfidenceDrivenRelaxation = saturate(gConfidenceDrivenRelaxationMultiplier * (1.0 - saturate(gIn_DiffConfidence.SampleLevel(gLinearClamp, pixelUv, 0))));

        // Relaxing normal weights for diffuse
        float r = saturate(diffConfidenceDrivenRelaxation * gConfidenceDrivenNormalEdgeStoppingRelaxation);
        diffuseLobeAngleFraction = lerp(diffuseLobeAngleFraction, 1.0, r);

        // Relaxing luminance weight for diffuse
        r = saturate(diffConfidenceDrivenRelaxation * gConfidenceDrivenLuminanceEdgeStoppingRelaxation);
        diffuseLuminanceWeightRelaxation = 1.0 - r;
    }
    float diffuseNormalWeightParam = GetNormalWeightParam2(1.0, diffuseLobeAngleFraction);

    float sumWDiffuse = 0.44198 * 0.44198;
    float4 sumDiffuseIlluminationAndVariance = centerDiffuseIlluminationAndVariance * float4(sumWDiffuse.xxx, sumWDiffuse * sumWDiffuse);
    #if( NRD_MODE == SH )
        float4 centerDiffuseSH = gIn_DiffSh[pixelPos];
        float4 sumDiffuseSH = centerDiffuseSH * sumWDiffuse;
    #endif
#endif

    float3 centerWorldPos = GetCurrentWorldPosFromPixelPos(pixelPos, centerViewZ);
    float3 centerV = -normalize(centerWorldPos);
    float3 centerSpecularMaterial = HoNrdSpecularGuide(pixelPos);
    static const float kernelWeightGaussian3x3[2] = { 0.44198, 0.27901 };
    float depthThreshold = gDepthThreshold * (gOrthoMode == 0 ? centerViewZ : 1.0);

    // Adding random offsets to minimize "ringing" at large A-Trous steps
    int2 offset = 0;
    if (gStepSize > 4)
    {
        Rng::Hash::Initialize(pixelPos, gFrameIndex);
        offset = int2(gStepSize.xx * 0.5 * (Rng::Hash::GetFloat2() - 0.5));
    }

    [unroll]
    for (int j = -1; j <= 1; j++)
    {
        [unroll]
        for (int i = -1; i <= 1; i++)
        {
            if (i == 0 && j == 0)
                continue;

            int2 p = pixelPos + offset + int2(i, j) * gStepSize;
            bool isInside = all(p >= int2(0, 0)) && all(p < gRectSize);
            float kernel = kernelWeightGaussian3x3[abs(i)] * kernelWeightGaussian3x3[abs(j)];

            // Fetching normal, roughness, linear Z
            float sampleMaterialID;
            float4 sampleNormalRoughnes = NRD_FrontEnd_UnpackNormalAndRoughness(gIn_Normal_Roughness[p], sampleMaterialID);
            float3 sampleNormal = sampleNormalRoughnes.rgb;
            float sampleRoughness = sampleNormalRoughnes.a;
            float sampleViewZ = UnpackViewZ(gIn_ViewZ[p]);

            // Calculating sample world position
            float3 sampleWorldPos = GetCurrentWorldPosFromPixelPos(p, sampleViewZ);

            // Calculating geometry weight for diffuse and specular
            float geometryW = GetPlaneDistanceWeight_Atrous(centerWorldPos, centerNormal, sampleWorldPos, depthThreshold);
            geometryW *= kernel;
            geometryW *= float(isInside && sampleViewZ < gDenoisingRange);

#if( NRD_SPEC )
            // Getting sample view vector closer to center view vector
            // by adding gRoughnessEdgeStoppingRelaxation * centerWorldPos
            // relaxes view direction based rejection
            float3 sampleV = -normalize(sampleWorldPos + gRoughnessEdgeStoppingRelaxation * centerWorldPos);

            // Calculating weights for specular
            float angles = Math::AcosApprox(dot(centerNormal, sampleNormal));
            float normalWSpecularSimplified = ComputeWeight(angles, specularNormalWeightParamSimplified, 0.0);
            float normalWSpecular = GetSpecularNormalWeight_ATrous(specularNormalWeightParams, centerNormal, sampleNormal, centerV, sampleV);
            float roughnessWSpecular = ComputeWeight(sampleRoughness, roughnessWeightParams.x, roughnessWeightParams.y);

            // Summing up specular
            float wSpecular = geometryW * (gRoughnessEdgeStoppingEnabled ? (normalWSpecular * roughnessWSpecular) : normalWSpecularSimplified);
            wSpecular *= CompareMaterials(sampleMaterialID, centerMaterialID, gSpecMinMaterial);
                wSpecular *= (isInside ? HoNrdSpecularMaterialWeight(centerSpecularMaterial, HoNrdSpecularGuide(p)) : 0.0);
            if (wSpecular > 1e-4)
            {
                float4 sampleSpecularIlluminationAndVariance = gIn_Spec_Variance[p];
                float sampleSpecularLuminance = Color::Luminance(sampleSpecularIlluminationAndVariance.rgb);

                float pairSpecularVar = min(centerSpecularVar, max(0.0, sampleSpecularIlluminationAndVariance.a));
                float specularLuminanceW = abs(centerSpecularLuminance - sampleSpecularLuminance) / max(1.0e-4, gSpecPhiLuminance * sqrt(pairSpecularVar));
                specularLuminanceW = min(gSpecMaxLuminanceRelativeDifference, specularLuminanceW);
                specularLuminanceW *= specularLuminanceWeightRelaxation;

                wSpecular *= exp(-specularLuminanceW);

                sumWSpecular += wSpecular;
                sumSpecularIlluminationAndVariance += float4(wSpecular.xxx, wSpecular * wSpecular) * sampleSpecularIlluminationAndVariance;
                #if( NRD_MODE == SH )
                    sumSpecularSH += gIn_SpecSh[p] * wSpecular;
                #endif
            }
#endif

#if( NRD_DIFF )
            // Calculating weights for diffuse
            float angled = Math::AcosApprox(dot(centerNormal, sampleNormal));
            float normalWDiffuse = ComputeWeight(angled, diffuseNormalWeightParam, 0.0);

            // Summing up diffuse
            float wDiffuse = geometryW * normalWDiffuse;
            wDiffuse *= CompareMaterials(sampleMaterialID, centerMaterialID, gDiffMinMaterial);
            if (wDiffuse > 1e-4)
            {
                float4 sampleDiffuseIlluminationAndVariance = gIn_Diff_Variance[p];
                float sampleDiffuseLuminance = Color::Luminance(sampleDiffuseIlluminationAndVariance.rgb);

                float pairDiffuseVar = min(max(0.0, centerDiffuseVar), max(0.0, sampleDiffuseIlluminationAndVariance.a));
                // Avoid cancellation between opposing RGB changes at colored
                // shadow boundaries; retain the same luminance units/bandwidth.
                float diffuseColorDistance = Color::Luminance(abs(centerDiffuseIlluminationAndVariance.rgb - sampleDiffuseIlluminationAndVariance.rgb));
                float diffuseLuminanceW = diffuseColorDistance / max(1.0e-4, gDiffPhiLuminance * sqrt(pairDiffuseVar));
                diffuseLuminanceW = min(gDiffMaxLuminanceRelativeDifference, diffuseLuminanceW);
                diffuseLuminanceW *= diffuseLuminanceWeightRelaxation;

                wDiffuse *= exp(-diffuseLuminanceW);

                sumWDiffuse += wDiffuse;
                sumDiffuseIlluminationAndVariance +=  float4(wDiffuse.xxx, wDiffuse * wDiffuse) * sampleDiffuseIlluminationAndVariance;
                #if( NRD_MODE == SH )
                    sumDiffuseSH += gIn_DiffSh[p] * wDiffuse;
                #endif
            }
#endif
        }
    }

    float currHistoryLength = max( historyLength - 1.0, 0.0 );
#if( NRD_SPEC )
    float4 filteredSpecularIlluminationAndVariance = float4(sumSpecularIlluminationAndVariance / float4(sumWSpecular.xxx, sumWSpecular * sumWSpecular));
    #if( NRD_MODE == SH )
        // Luminance output is expected in YCoCg color space in SH mode, converting to YCoCg in last A-Trous pass
        if (gIsLastPass == 1)
            filteredSpecularIlluminationAndVariance.rgb = _NRD_LinearToYCoCg(filteredSpecularIlluminationAndVariance.rgb);
        gOut_SpecSh[pixelPos] = float4(sumSpecularSH.rgb / sumWSpecular, roughnessModified);
    #endif
    if (gIsLastPass == 1)
        filteredSpecularIlluminationAndVariance.w = currHistoryLength;
    gOut_Spec_Variance[pixelPos] = filteredSpecularIlluminationAndVariance;
#endif

#if( NRD_DIFF )
    // Use fixed pair exchange coefficients instead of a row-dependent
    // normalization. Rejected neighbor weight stays at the center.
    const float diffuseCenterKernel = 0.44198 * 0.44198;
    float retainedDiffuseWeight = saturate(1.0 - (sumWDiffuse - diffuseCenterKernel));
    float4 diffuseNeighborSum = sumDiffuseIlluminationAndVariance - centerDiffuseIlluminationAndVariance * float4(diffuseCenterKernel.xxx, diffuseCenterKernel * diffuseCenterKernel);
    float4 filteredDiffuseIlluminationAndVariance = diffuseNeighborSum + centerDiffuseIlluminationAndVariance * float4(retainedDiffuseWeight.xxx, retainedDiffuseWeight * retainedDiffuseWeight);
    #if( NRD_MODE == SH )
        // Luminance output is expected in YCoCg color space in SH mode, converting to YCoCg in last A-Trous pass
        if (gIsLastPass == 1)
            filteredDiffuseIlluminationAndVariance.rgb = _NRD_LinearToYCoCg(filteredDiffuseIlluminationAndVariance.rgb);
        gOut_DiffSh[pixelPos] = sumDiffuseSH / sumWDiffuse;
    #endif
    if (gIsLastPass == 1)
        filteredDiffuseIlluminationAndVariance.w = currHistoryLength;
    gOut_Diff_Variance[pixelPos] = filteredDiffuseIlluminationAndVariance;
#endif
}
