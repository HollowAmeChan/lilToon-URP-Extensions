#pragma warning disable CS0618, CS0672

using lilToon.URP.Extensions.Debugging;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.RenderGraphModule;
using UnityEngine.Rendering.Universal;
using lilToon.URP.Extensions.ObjectBuffer;
using lilToon.URP.Extensions.SurfaceBuffer;

namespace lilToon.URP.Extensions.AttributeComposite
{
    /// <summary>
    /// AC 的调试直出：把 Selection 池画到相机颜色上（与 OB 的调试 pass 同形）。
    /// AC 架构 §12：没有 debug 视图与登记就不算落地 —— AC 至少要能看到合成语义槽。
    /// **这趟只做"看"，不产出任何东西**，所以它可以被随时关掉。
    /// </summary>
    internal sealed class HoAttributeCompositeDebugPass : HoDebugRenderPass
    {
        private static readonly ProfilingSampler ProfilingSampler = new ProfilingSampler("Ho-AttributeComposite Debug");
        private static readonly int BlitScaleBiasId = Shader.PropertyToID("_BlitScaleBias");
        private static readonly int DebugQueryId = Shader.PropertyToID("_HoACDebugQuery");
        private static readonly int DebugCategoryId = Shader.PropertyToID("_HoACDebugCategory");
        private static readonly int DebugFocusId = Shader.PropertyToID("_HoACDebugFocus");
        private static readonly int DebugColorsId = Shader.PropertyToID("_HoACDebugColors");

        private HoAttributeCompositeSettings settings;
        private Material debugMaterial;
        private RTHandle cameraColorTarget;

        private sealed class PassData
        {
            public Material material;
            public HoAttributeCompositeDebugMode debugMode;
            public TextureHandle[] selectionTextures;
            public HoAttributeCompositeRenderGraphResources resources;
            public HoACQueryDescriptor query;
            public Vector4 lane;
            public bool laneValid;
            public bool semanticDebug;
            public HoACDebugCategory category;
            public bool focus;
            public Vector4[] colors;
            public HoACQueryDescriptor overviewQuery;
        }

        public void Setup(HoAttributeCompositeSettings settings, Material debugMaterial, RTHandle cameraColorTarget)
        {
            this.settings = settings;
            this.debugMaterial = debugMaterial;
            this.cameraColorTarget = cameraColorTarget;
            if (settings != null && HoAttributeCompositeSettings.IsSemanticDebug(settings.debugMode))
                HoObjectBufferRegistry.EnsureBuilt();
            renderPassEvent = RenderPassEvent.AfterRenderingPostProcessing;
            ConfigureInput(ScriptableRenderPassInput.None);
        }

        public void ReleaseCompatibilityResources()
        {
            ReleaseDebugResources();
            cameraColorTarget = null;
        }

        public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
        {
            if (settings == null || debugMaterial == null || cameraColorTarget == null)
            {
                return;
            }

            CommandBuffer cmd = CommandBufferPool.Get();
            using (new ProfilingScope(cmd, ProfilingSampler))
            {
                debugMaterial.SetFloat(HoAttributeCompositeShaderConstants.DebugModeId, (float)settings.debugMode);
                cmd.SetGlobalVector(BlitScaleBiasId, new Vector4(1, 1, 0, 0));
                bool laneValid = HoAttributeCompositeSettings.TryResolveDebugLane(settings.debugSemanticName, out Vector4 lane);
                cmd.SetGlobalVector(HoAttributeCompositeShaderConstants.DebugLaneId, lane);
                cmd.SetGlobalFloat(HoAttributeCompositeShaderConstants.DebugLaneValidId, laneValid ? 1 : 0);
                cmd.SetGlobalFloat(HoAttributeCompositeShaderConstants.DebugSurfaceAvailableId,
                    HoSurfaceBufferSemanticPass.LastProduced ? 1 : 0);
                HoAttributeCompositePass.BindCompatibilityDiagnostics(cmd);
                var query = settings.ResolveDebugQuery();
                HoAttributeCompositePass.BindCompatibilityQuery(cmd, query);
                cmd.SetGlobalVector(DebugQueryId, query.ShaderValue);
                if (settings.IsPresentationDebug)
                {
                    cmd.SetGlobalFloat(DebugCategoryId, (int)settings.debugCategory);
                    cmd.SetGlobalFloat(DebugFocusId, string.IsNullOrEmpty(settings.debugTarget) ? 0 : 1);
                    cmd.SetGlobalVectorArray(DebugColorsId, HoACDebugCatalog.BuildColors(settings.debugCategory));
                    // A focus query can narrow demand, but the overview still reads every color source.
                    HoAttributeCompositePass.BindCompatibilityQuery(cmd, HoACDebugCatalog.OverviewQuery(settings.debugCategory));
                }
                CoreUtils.DrawFullScreen(cmd, debugMaterial, shaderPassId: 0);
            }

            PublishCompatibility(renderingData.cameraData.camera);
            context.ExecuteCommandBuffer(cmd);
            CommandBufferPool.Release(cmd);
        }

        public override void RecordRenderGraph(RenderGraph renderGraph, ContextContainer frameData)
        {
            if (settings == null || debugMaterial == null || settings.debugMode == HoAttributeCompositeDebugMode.Off)
            {
                return;
            }

            UniversalResourceData resourceData = frameData.Get<UniversalResourceData>();
            HoAttributeCompositeRenderGraphResources resources = frameData.GetOrCreate<HoAttributeCompositeRenderGraphResources>();
            if (!resources.published)
            {
                return;
            }

            TextureHandle destination = CreateDebugTarget(renderGraph, frameData);

            using (var builder = renderGraph.AddRasterRenderPass<PassData>("Ho-AttributeComposite Debug", out PassData passData, ProfilingSampler))
            {
                passData.material = debugMaterial;
                passData.debugMode = settings.debugMode;
                passData.selectionTextures = resources.selectionTextures;
                passData.resources = resources;
                passData.semanticDebug = HoAttributeCompositeSettings.IsSemanticDebug(settings.debugMode);
                passData.laneValid = HoAttributeCompositeSettings.TryResolveDebugLane(settings.debugSemanticName, out passData.lane);
                passData.query = settings.ResolveDebugQuery();
                passData.category = settings.debugCategory;
                passData.focus = !string.IsNullOrEmpty(settings.debugTarget);
                passData.colors = settings.IsPresentationDebug ? HoACDebugCatalog.BuildColors(settings.debugCategory) : null;
                passData.overviewQuery = HoACDebugCatalog.OverviewQuery(settings.debugCategory);
                HoAttributeCompositeBindings.ReadQuery(builder, resources, passData.query);
                if (settings.IsPresentationDebug) HoAttributeCompositeBindings.ReadQuery(builder, resources, passData.overviewQuery);
                HoAttributeCompositeBindings.Read(builder,resources.outlineOwnerTexture);
                if (passData.semanticDebug)
                {
                    HoAttributeCompositeBindings.Read(builder,resources.rawIdentityId0Texture);
                    HoAttributeCompositeBindings.Read(builder,resources.rawIdentityId1Texture);
                    HoAttributeCompositeBindings.Read(builder,resources.rawIdentityCoverageTexture);
                    if (resources.HasCorrelatedSemantics)
                    {
                        HoAttributeCompositeBindings.Read(builder, resources.semanticWrittenCoverageTexture);
                        HoAttributeCompositeBindings.Read(builder, resources.semanticWeightedCoverageTexture);
                        HoAttributeCompositeBindings.Read(builder, resources.semanticAssociationStatusTexture);
                    }
                    HoAttributeCompositeBindings.Read(builder, resources.identityId0Texture);
                    HoAttributeCompositeBindings.Read(builder, resources.identityId1Texture);
                    HoAttributeCompositeBindings.Read(builder, resources.identityCoverageTexture);
                    if (resources.HasSurfaceSemantics)
                    {
                        HoAttributeCompositeBindings.Read(builder, resources.semanticOwnerTexture);
                        for (int i = 0; i < resources.semanticLaneTextures.Length; i++)
                            HoAttributeCompositeBindings.Read(builder, resources.semanticLaneTextures[i]);
                    }
                }

                for (int i = 0; i < resources.selectionTextures.Length; i++)
                {
                    if (resources.selectionTextures[i].IsValid())
                    {
                        builder.UseTexture(resources.selectionTextures[i], AccessFlags.Read);
                    }
                }

                builder.SetRenderAttachment(destination, 0, AccessFlags.Write);
                builder.AllowGlobalStateModification(true);
                builder.AllowPassCulling(false);
                builder.SetRenderFunc(static (PassData data, RasterGraphContext context) =>
                {
                    data.material.SetFloat(HoAttributeCompositeShaderConstants.DebugModeId, (float)data.debugMode);
                    context.cmd.SetGlobalVector(BlitScaleBiasId, new Vector4(1, 1, 0, 0));
                    HoAttributeCompositeBindings.BindQuery(context.cmd, data.resources, data.query);
                    context.cmd.SetGlobalVector(DebugQueryId, data.query.ShaderValue);
                    if (data.colors != null)
                    {
                        HoAttributeCompositeBindings.BindQuery(context.cmd, data.resources, data.overviewQuery);
                        context.cmd.SetGlobalFloat(DebugCategoryId, (int)data.category);
                        context.cmd.SetGlobalFloat(DebugFocusId, data.focus ? 1 : 0);
                        context.cmd.SetGlobalVectorArray(DebugColorsId, data.colors);
                    }
                    context.cmd.SetGlobalFloat(HoAttributeCompositeShaderConstants.OutlineInheritanceActiveId,data.resources.outlineOwnerTexture.IsValid() ? 1 : 0);
                    if (data.resources.outlineOwnerTexture.IsValid()) context.cmd.SetGlobalTexture(HoAttributeCompositeShaderConstants.OutlineOwnerId,data.resources.outlineOwnerTexture);
                    bool rawAvailable = data.semanticDebug && data.resources.rawIdentityId0Texture.IsValid();
                    context.cmd.SetGlobalFloat(HoAttributeCompositeShaderConstants.RawInputsAvailableId,rawAvailable ? 1 : 0);
                    if (rawAvailable)
                    {
                        context.cmd.SetGlobalTexture(HoAttributeCompositeShaderConstants.RawIdentityIds[0],data.resources.rawIdentityId0Texture);
                        context.cmd.SetGlobalTexture(HoAttributeCompositeShaderConstants.RawIdentityIds[1],data.resources.rawIdentityId1Texture);
                        context.cmd.SetGlobalTexture(HoAttributeCompositeShaderConstants.RawIdentityIds[2],data.resources.rawIdentityCoverageTexture);
                    }
                    context.cmd.SetGlobalVector(HoAttributeCompositeShaderConstants.DebugLaneId, data.lane);
                    context.cmd.SetGlobalFloat(HoAttributeCompositeShaderConstants.DebugLaneValidId, data.laneValid ? 1 : 0);
                    context.cmd.SetGlobalFloat(HoAttributeCompositeShaderConstants.DebugSurfaceAvailableId, data.resources.HasSurfaceSemantics ? 1 : 0);
                    context.cmd.SetGlobalFloat(HoAttributeCompositeShaderConstants.ActiveId, data.resources.HasSelectionPool ? 1 : 0);
                    context.cmd.SetGlobalFloat(HoAttributeCompositeShaderConstants.PrecisionActiveId, data.resources.HasCorrelatedSemantics ? 1 : 0);
                    if (data.semanticDebug && data.resources.HasCorrelatedSemantics)
                    {
                        context.cmd.SetGlobalTexture(HoAttributeCompositeShaderConstants.WrittenCoverageId, data.resources.semanticWrittenCoverageTexture);
                        context.cmd.SetGlobalTexture(HoAttributeCompositeShaderConstants.WeightedCoverageId, data.resources.semanticWeightedCoverageTexture);
                        context.cmd.SetGlobalTexture(HoAttributeCompositeShaderConstants.AssociationStatusId, data.resources.semanticAssociationStatusTexture);
                    }
                    if (data.semanticDebug)
                    {
                        if (data.resources.HasIdentityPool)
                        {
                            context.cmd.SetGlobalTexture(HoObjectBufferShaderConstants.Id0TextureId, data.resources.identityId0Texture);
                            context.cmd.SetGlobalTexture(HoObjectBufferShaderConstants.Id1TextureId, data.resources.identityId1Texture);
                            context.cmd.SetGlobalTexture(HoObjectBufferShaderConstants.CoverageTextureId, data.resources.identityCoverageTexture);
                        }
                        if (data.resources.HasSurfaceSemantics)
                        {
                            context.cmd.SetGlobalTexture(HoSurfaceBufferShaderConstants.SemanticOwnerTextureId, data.resources.semanticOwnerTexture);
                            for (int i = 0; i < data.resources.semanticLaneTextures.Length; i++)
                                context.cmd.SetGlobalTexture(HoSurfaceBufferShaderConstants.GetSemanticLaneTextureId(i), data.resources.semanticLaneTextures[i]);
                        }
                    }
                    for (int i = 0; i < data.selectionTextures.Length; i++)
                    {
                        if (data.selectionTextures[i].IsValid())
                        {
                            context.cmd.SetGlobalTexture(HoAttributeCompositeShaderConstants.SelectionTextureIds[i], data.selectionTextures[i]);
                        }
                    }

                    context.cmd.DrawProcedural(Matrix4x4.identity, data.material, 0, MeshTopology.Triangles, 3, 1);
                });
            }
        }
    }
}
