#pragma warning disable CS0618, CS0672

using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using lilToon.URP.Extensions.SurfaceBuffer;

namespace lilToon.URP.Extensions.AttributeComposite
{
    /// <summary>
    /// **AC（Ho-AttributeComposite）= 语义遮罩与合成属性的唯一逻辑入口**（AC 架构 §1）。
    /// 发布 GB 覆盖范围、OB 身份引用、SB 数值引用，并合成固定 8 lane 的 Selection 池。
    /// 消费者经 typed query 选择遮罩与范围。Scalar V1 支持样本关联合成；按需求裁剪尚未实现。
    /// </summary>
    [DisallowMultipleRendererFeature("Ho-AttributeComposite")]
    public sealed class HoAttributeCompositeRendererFeature : ScriptableRendererFeature
    {
        [SerializeField]
        private HoAttributeCompositeSettings settings = new HoAttributeCompositeSettings();

        private readonly HoAttributeCompositeSettings runtimeSettings = new HoAttributeCompositeSettings();
        private HoAttributeCompositePass pass;
        private HoAttributeCompositeDebugPass debugPass;
        private Material resolveMaterial;
        private Material debugMaterial;
        private Shader resolveShader;
        private Shader debugShader;
        private bool warnedMissingResolveShader;
        private bool registeredCameraReset;

        public HoAttributeCompositeSettings Settings => settings;

        public override void SetupRenderPasses(ScriptableRenderer renderer, in RenderingData renderingData)
        {
            // URP creates the camera target after AddRenderPasses. Compatibility debug binds it here.
            if (runtimeSettings.enabled && WantsDebugView(runtimeSettings, renderingData.cameraData.cameraType))
                debugPass?.Setup(runtimeSettings, debugMaterial, renderer.cameraColorTargetHandle);
        }

        public override void Create()
        {
            HoAttributeCompositeConsumerRegistry.EnsureInitialized();
            if (!registeredCameraReset)
            {
                RenderPipelineManager.beginCameraRendering += ResetCameraState;
                registeredCameraReset = true;
            }
            pass = new HoAttributeCompositePass();
            debugPass?.ReleaseDebugResources();
            debugPass = new HoAttributeCompositeDebugPass();
        }

        public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
        {
            HoAttributeCompositeConsumerRegistry.Remove(this, renderingData.cameraData.camera);
            HoAttributeCompositeSettings activeSettings = ResolveSettings(in renderingData);
            if (activeSettings == null || !activeSettings.enabled)
            {
                pass?.ReleaseCompatibilityResources();
                debugPass?.ReleaseCompatibilityResources();
                HoAttributeCompositePass.ResetGlobalState();
                return;
            }

            EnsureMaterials();
            if (resolveMaterial == null)
            {
                HoAttributeCompositePass.ResetGlobalState();
                return;
            }

            pass?.UploadLaneCatalogIfNeeded();
            pass?.Setup(activeSettings, resolveMaterial);
            renderer.EnqueuePass(pass);

            if (WantsDebugView(activeSettings, renderingData.cameraData.cameraType))
            {
                HoAttributeCompositeDemandDebug.Declare(renderingData.cameraData.camera, this, activeSettings);
                debugPass?.Setup(activeSettings, debugMaterial, null);
                debugPass.Enqueue(renderer);
            }
            else debugPass?.ReleaseDebugResources();
        }

        protected override void Dispose(bool disposing)
        {
            HoAttributeCompositeConsumerRegistry.Remove(this);
            if (registeredCameraReset)
            {
                RenderPipelineManager.beginCameraRendering -= ResetCameraState;
                registeredCameraReset = false;
            }
            pass?.Dispose();
            pass = null;
            debugPass?.ReleaseCompatibilityResources();
            debugPass = null;
            CoreUtils.Destroy(resolveMaterial);
            CoreUtils.Destroy(debugMaterial);
            resolveMaterial = null;
            debugMaterial = null;
            resolveShader = null;
            debugShader = null;
        }

        private HoAttributeCompositeSettings ResolveSettings(in RenderingData renderingData)
        {
            runtimeSettings.CopyFrom(settings);
            HoAttributeCompositeVolume volume = GetVolumeComponent();
            if (volume == null || !volume.active)
            {
                return runtimeSettings;
            }

            if (volume.enable.overrideState) runtimeSettings.enabled = volume.enable.value;
            if (!volume.IsActive()) return runtimeSettings;
            runtimeSettings.debugMode = volume.debugMode.value;
            runtimeSettings.debugCategory = volume.debugCategory.value;
            runtimeSettings.debugTarget = volume.debugTarget.value;
            runtimeSettings.debugSemanticName = volume.debugSemanticName.value;
            runtimeSettings.debugSelectionName = volume.debugSelectionName.value;
            runtimeSettings.debugGroupId = volume.debugGroupId.value;
            runtimeSettings.debugInSceneView = volume.debugInSceneView.value;
            runtimeSettings.debugInGameView = volume.debugInGameView.value;
            return runtimeSettings;
        }

        private static HoAttributeCompositeVolume GetVolumeComponent()
        {
            VolumeStack stack = VolumeManager.instance != null ? VolumeManager.instance.stack : null;
            return stack != null ? stack.GetComponent<HoAttributeCompositeVolume>() : null;
        }

        private static void ResetCameraState(ScriptableRenderContext context, Camera camera)
        {
            HoAttributeCompositePass.ResetGlobalState();
            HoSurfaceSemanticPrecisionDiagnostics.Publish(camera, 0, "Surface producer not recorded");
        }

        private static bool WantsDebugView(HoAttributeCompositeSettings activeSettings, CameraType cameraType)
        {
            if (activeSettings.debugMode == HoAttributeCompositeDebugMode.Off)
            {
                return false;
            }

            bool isSceneView = cameraType == CameraType.SceneView;
            return isSceneView ? activeSettings.debugInSceneView : activeSettings.debugInGameView;
        }

        private void EnsureMaterials()
        {
            EnsureMaterial(ref resolveMaterial, ref resolveShader, HoAttributeCompositeShaderConstants.ResolveShaderName, ref warnedMissingResolveShader);
            EnsureMaterial(ref debugMaterial, ref debugShader, HoAttributeCompositeShaderConstants.DebugShaderName, ref warnedMissingResolveShader);
        }

        private static void EnsureMaterial(ref Material material, ref Shader cachedShader, string shaderName, ref bool warned)
        {
            Shader shader = Shader.Find(shaderName);
            if (material != null && cachedShader == shader)
            {
                return;
            }

            CoreUtils.Destroy(material);
            material = null;
            cachedShader = shader;
            if (shader == null)
            {
                if (!warned)
                {
                    warned = true;
                    Debug.LogWarning($"[Ho-AttributeComposite] 找不到 shader '{shaderName}'，相关步骤会跳过。");
                }

                return;
            }

            material = CoreUtils.CreateEngineMaterial(shader);
        }
    }
}
